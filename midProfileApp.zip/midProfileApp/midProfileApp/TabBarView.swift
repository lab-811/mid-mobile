//
//  ContentView.swift
//  midProfileApp
//
//  Created by Islambek on 15.10.2021.
//

import SwiftUI

struct TabBarView: View {
    @State var tabIndex = "profile"
    init() {
        UITabBar.appearance().backgroundColor = UIColor.white
    }
    var body: some View {
        TabView(selection: $tabIndex) {
            
            Color("Background 3")
                .ignoresSafeArea()
                .tabItem{
                    Image(systemName: "house.fill")
                }
                .tag("house")
            
            
            Color("Background 3")
                .ignoresSafeArea()
                .tabItem {
                    Image(systemName: "square.grid.4x3.fill")
                }
                .tag("cube")
            
            NavigationView {
                
                VStack {
                    ProfileContentView()
                    
                    ButtonView()
                    
                    Spacer()
                }
                .navigationBarItems(trailing: Image(systemName: "rectangle.righthalf.inset.filled.arrow.right"))
                .navigationBarTitle("Профиль")
                .background(Color("Background 3").ignoresSafeArea())
                
                
                
            }
            .tabItem {
                Image(systemName: "person")
            }
            .tag("profile")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        TabBarView()
    }
}
