//
//  ProfileContentView.swift
//  midProfileApp
//
//  Created by Islambek on 15.10.2021.
//

import SwiftUI

struct ProfileContentView: View {
    @State private var profileName = ""
    @State private var profilePhone = ""
    
    var body: some View {
        VStack {
            VStack(alignment: .leading) {
                Text("Имя")
                
                HStack {
                    TextField("Имя", text: $profileName)
                    Image(systemName: "pencil")
                }
                .font(.title2)
                .padding(7)
                .background(Color("Background 3"))
                .clipShape(RoundedRectangle(cornerRadius: 5))
                Text("Телефон")
                
                TextField("телефон", text: $profilePhone)
                    .font(.title2)
                    .padding(7)
                    .background(Color("Background 3"))
                    .clipShape(RoundedRectangle(cornerRadius: 5))
                
                Spacer()
            }
            .frame(height: 200)
            .padding(15)
            .background(Color.white)
            .cornerRadius(18)
            .shadow(color: Color("Background 3"), radius: 18, x: 0, y: 15)
            .padding()
        }
    }
}

struct ProfileContentView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileContentView()
    }
}
