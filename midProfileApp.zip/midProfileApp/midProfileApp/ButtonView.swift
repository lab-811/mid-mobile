//
//  ButtonView.swift
//  midProfileApp
//
//  Created by Islmabek on 15.10.2021.
//

import SwiftUI

struct ButtonView: View {
    var body: some View {
        Button {
           
            
        } label: {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .frame(height: 49)
                
                
                Text("История добавления товаров")
                    .foregroundColor(.white)
                    
            }
            .padding()
        }
    }
}

struct ButtonView_Previews: PreviewProvider {
    static var previews: some View {
        ButtonView()
    }
}
