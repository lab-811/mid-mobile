//
//  midProfileAppApp.swift
//  midProfileApp
//
//  Created by Islambek on 15.10.2021.
//

import SwiftUI

@main
struct midProfileAppApp: App {
    var body: some Scene {
        WindowGroup {
            TabBarView()
        }
    }
}
